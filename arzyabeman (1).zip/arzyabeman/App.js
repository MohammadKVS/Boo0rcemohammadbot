import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import HomeScreen from './screens/HomeScreen';
import ReportScreen from './screens/ReportScreen';
import SavedReportsScreen from './screens/SavedReportsScreen';
import SavedFilesScreen from './screens/SavedFilesScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="خانه" component={HomeScreen} />
        <Stack.Screen name="گزارش نسخه" component={ReportScreen} />
        <Stack.Screen name="گزارش‌های ذخیره‌شده" component={SavedReportsScreen} />
        <Stack.Screen name="فایل‌های ذخیره‌شده" component={SavedFilesScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}